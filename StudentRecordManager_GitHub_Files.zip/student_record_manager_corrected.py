import re
import os

# Always find input.txt and students.txt in the same folder as this Python file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_FILE = os.path.join(BASE_DIR, "input.txt")
OUTPUT_FILE = os.path.join(BASE_DIR, "students.txt")


def validate_gmail(email):
    """Validate Gmail address using Regex."""
    pattern = r"^[a-zA-Z0-9._%+-]+@gmail\.com$"
    return re.fullmatch(pattern, email) is not None


def validate_student(roll_no, name, email, age):
    """Validate all student details."""
    if not roll_no.isdigit():
        raise ValueError("Invalid Roll Number")

    if not name.strip() or not re.fullmatch(r"[A-Za-z ]+", name):
        raise ValueError("Invalid Name")

    if not validate_gmail(email):
        raise ValueError("Invalid Gmail")

    if not age.isdigit() or not 1 <= int(age) <= 100:
        raise ValueError("Invalid Age")


def read_input_file():
    """Read and validate student records from input.txt."""
    try:
        with open(INPUT_FILE, "r", encoding="utf-8") as file:
            lines = file.readlines()

    except FileNotFoundError:
        print("Error: input.txt file not found.")
        print("Please keep input.txt in the same folder as this Python file.")
        return []

    students = []

    for line_number, line in enumerate(lines, start=1):
        line = line.strip()

        if not line:
            continue

        try:
            data = line.split("|")

            if len(data) != 4:
                raise ValueError(
                    "Incorrect format. Use: Roll Number|Name|Gmail|Age"
                )

            roll_no, name, email, age = [
                item.strip() for item in data
            ]

            validate_student(roll_no, name, email, age)

            students.append((roll_no, name, email, age))

        except ValueError as error:
            print(f"Invalid record on line {line_number}: {error}")

    return students


def save_students(students):
    """Save valid student records to students.txt."""
    try:
        with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
            for roll_no, name, email, age in students:
                file.write(
                    f"{roll_no}|{name}|{email}|{age}\n"
                )

        print("\nStudent data saved successfully.")
        print(f"Saved file: {OUTPUT_FILE}")

    except OSError as error:
        print("Error while saving student data:", error)


def display_students():
    """Read and display saved student records."""
    try:
        with open(OUTPUT_FILE, "r", encoding="utf-8") as file:
            print("\n===== STUDENT RECORDS =====")

            for line in file:
                parts = line.strip().split("|")

                if len(parts) == 4:
                    roll_no, name, email, age = parts

                    print("Roll Number :", roll_no)
                    print("Name        :", name)
                    print("Gmail       :", email)
                    print("Age         :", age)
                    print("---------------------------")

    except FileNotFoundError:
        print("No student data found.")


def main():
    print("===== STUDENT RECORD MANAGER =====")

    students = read_input_file()

    if not students:
        print("\nNo valid student records found.")
        return

    print(f"\n{len(students)} valid student record(s) found.")

    save_students(students)
    display_students()


if __name__ == "__main__":
    main()
